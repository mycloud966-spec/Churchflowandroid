package com.churchflow.android;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 1001;
    private static final int PICK_VIDEO = 1002;

    private final List<String> slides = new ArrayList<>();
    private int currentSlide = 0;
    private boolean blackout = false;
    private Uri backgroundImageUri;
    private Uri backgroundVideoUri;

    private EditText lyricsEditor;
    private TextView slideCounter;
    private TextView previewText;
    private ImageView previewImage;
    private VideoView previewVideo;
    private View previewBlackout;
    private PresentationOutput presentation;
    private DisplayManager displayManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        displayManager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        setContentView(buildUi());
        seedLyrics();
        rebuildSlides();
    }

    private View buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(13, 19, 33));

        TextView title = new TextView(this);
        title.setText("ChurchFlow Android 0.1 Test");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22f);
        title.setPadding(dp(16), dp(16), dp(16), dp(8));
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Phone controls the presentation. TV/secondary display gets a clean full-screen output.");
        subtitle.setTextColor(0xFFB7C2D8);
        subtitle.setPadding(dp(16), 0, dp(16), dp(12));
        page.addView(subtitle);

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12), 0, dp(12), dp(24));
        scroll.addView(body);

        lyricsEditor = new EditText(this);
        lyricsEditor.setTextColor(Color.WHITE);
        lyricsEditor.setHintTextColor(0xFF7E8AA5);
        lyricsEditor.setHint("Paste Telugu/English lyrics here");
        lyricsEditor.setMinLines(8);
        lyricsEditor.setGravity(Gravity.TOP | Gravity.START);
        lyricsEditor.setBackgroundColor(0xFF172036);
        lyricsEditor.setPadding(dp(12), dp(12), dp(12), dp(12));
        body.addView(lyricsEditor, matchWrap());

        Button split = button("Smart Split (2 lines/slide)");
        split.setOnClickListener(v -> {
            rebuildSlides();
            toast("Slides updated");
        });
        body.addView(split, matchWrap());

        LinearLayout castRow = row();
        Button cast = button("TV Cast");
        cast.setOnClickListener(v -> connectPresentation());
        Button disconnect = button("Disconnect TV");
        disconnect.setOnClickListener(v -> disconnectPresentation());
        castRow.addView(cast, weighted());
        castRow.addView(disconnect, weighted());
        body.addView(castRow, matchWrap());

        LinearLayout bgRow = row();
        Button image = button("Background Image");
        image.setOnClickListener(v -> pickFile("image/*", PICK_IMAGE));
        Button video = button("Background Video");
        video.setOnClickListener(v -> pickFile("video/*", PICK_VIDEO));
        bgRow.addView(image, weighted());
        bgRow.addView(video, weighted());
        body.addView(bgRow, matchWrap());

        Button clear = button("Clear Background");
        clear.setOnClickListener(v -> {
            backgroundImageUri = null;
            backgroundVideoUri = null;
            updateOutputs();
        });
        body.addView(clear, matchWrap());

        FrameLayout preview = new FrameLayout(this);
        preview.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(220));
        previewLp.setMargins(0, dp(12), 0, dp(8));
        body.addView(preview, previewLp);

        previewImage = new ImageView(this);
        previewImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        preview.addView(previewImage, frameMatch());

        previewVideo = new VideoView(this);
        previewVideo.setVisibility(View.GONE);
        preview.addView(previewVideo, frameMatch());

        View shade = new View(this);
        shade.setBackgroundColor(0x55000000);
        preview.addView(shade, frameMatch());

        previewText = new TextView(this);
        previewText.setTextColor(Color.WHITE);
        previewText.setTextSize(24f);
        previewText.setGravity(Gravity.CENTER);
        previewText.setShadowLayer(8f, 0f, 3f, Color.BLACK);
        previewText.setPadding(dp(18), dp(12), dp(18), dp(12));
        preview.addView(previewText, frameMatch());

        previewBlackout = new View(this);
        previewBlackout.setBackgroundColor(Color.BLACK);
        previewBlackout.setVisibility(View.GONE);
        preview.addView(previewBlackout, frameMatch());

        slideCounter = new TextView(this);
        slideCounter.setTextColor(0xFFB7C2D8);
        slideCounter.setGravity(Gravity.CENTER);
        body.addView(slideCounter, matchWrap());

        LinearLayout transport = row();
        Button prev = button("◀ Previous");
        prev.setOnClickListener(v -> previousSlide());
        Button black = button("Blackout");
        black.setOnClickListener(v -> {
            blackout = !blackout;
            updateOutputs();
        });
        Button next = button("Next ▶");
        next.setOnClickListener(v -> nextSlide());
        transport.addView(prev, weighted());
        transport.addView(black, weighted());
        transport.addView(next, weighted());
        body.addView(transport, matchWrap());

        TextView note = new TextView(this);
        note.setText("Secondary-display output uses Android Presentation, so the TV shows only the clean slide instead of mirroring phone controls. Chromecast integration is reserved for a later build.");
        note.setTextColor(0xFF95A3BF);
        note.setPadding(dp(6), dp(14), dp(6), 0);
        body.addView(note, matchWrap());

        page.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return page;
    }

    private void seedLyrics() {
        lyricsEditor.setText("పల్లవి:\nయేసయ్యా నీ ప్రేమ ఎంతో గొప్పది\nనా హృదయం నీకే అర్పించెదన్\n\nచరణం 1:\nనీ కృప నన్ను నడిపించును\nప్రతి దినం నీతో సాగెదన్\n\nచరణం 2:\nనీ వెలుగు నా మార్గములో\nనిత్యము నన్ను కాపాడును");
    }

    private void rebuildSlides() {
        slides.clear();
        String text = lyricsEditor.getText().toString().replace("\r", "");
        String[] lines = text.split("\n");
        List<String> bucket = new ArrayList<>();
        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) {
                flushBucket(bucket);
                continue;
            }
            bucket.add(line);
            if (bucket.size() == 2) flushBucket(bucket);
        }
        flushBucket(bucket);
        if (slides.isEmpty()) slides.add("");
        currentSlide = Math.min(currentSlide, slides.size() - 1);
        blackout = false;
        updateOutputs();
    }

    private void flushBucket(List<String> bucket) {
        if (bucket.isEmpty()) return;
        slides.add(String.join("\n", bucket));
        bucket.clear();
    }

    private void nextSlide() {
        if (slides.isEmpty()) rebuildSlides();
        currentSlide = Math.min(slides.size() - 1, currentSlide + 1);
        blackout = false;
        updateOutputs();
    }

    private void previousSlide() {
        if (slides.isEmpty()) rebuildSlides();
        currentSlide = Math.max(0, currentSlide - 1);
        blackout = false;
        updateOutputs();
    }

    private void connectPresentation() {
        Display[] displays = displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        if (displays.length == 0) {
            toast("No secondary presentation display detected. Connect/cast the phone to a compatible display first.");
            return;
        }
        disconnectPresentation();
        presentation = new PresentationOutput(this, displays[0]);
        try {
            presentation.show();
            updateOutputs();
            toast("TV presentation connected");
        } catch (Exception e) {
            presentation = null;
            toast("Could not open the secondary display");
        }
    }

    private void disconnectPresentation() {
        if (presentation != null) {
            try { presentation.dismiss(); } catch (Exception ignored) {}
            presentation = null;
        }
    }

    private void updateOutputs() {
        String text = slides.isEmpty() ? "" : slides.get(Math.max(0, Math.min(currentSlide, slides.size() - 1)));
        previewText.setText(blackout ? "" : text);
        previewBlackout.setVisibility(blackout ? View.VISIBLE : View.GONE);
        slideCounter.setText((currentSlide + 1) + " / " + Math.max(1, slides.size()));
        updatePreviewBackground();
        if (presentation != null && presentation.isShowing()) {
            presentation.update(text, blackout, backgroundImageUri, backgroundVideoUri);
        }
    }

    private void updatePreviewBackground() {
        if (backgroundVideoUri != null) {
            previewImage.setImageDrawable(null);
            previewVideo.setVideoURI(backgroundVideoUri);
            previewVideo.setOnPreparedListener(mp -> {
                mp.setLooping(true);
                previewVideo.start();
            });
            previewVideo.setVisibility(View.VISIBLE);
        } else {
            if (previewVideo.isPlaying()) previewVideo.stopPlayback();
            previewVideo.setVisibility(View.GONE);
        }

        if (backgroundImageUri != null && backgroundVideoUri == null) {
            try (InputStream in = getContentResolver().openInputStream(backgroundImageUri)) {
                previewImage.setImageDrawable(Drawable.createFromStream(in, backgroundImageUri.toString()));
            } catch (Exception ignored) {
                previewImage.setImageDrawable(null);
            }
        } else if (backgroundImageUri == null) {
            previewImage.setImageDrawable(null);
        }
    }

    private void pickFile(String mime, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        if (requestCode == PICK_IMAGE) {
            backgroundImageUri = uri;
            backgroundVideoUri = null;
        } else if (requestCode == PICK_VIDEO) {
            backgroundVideoUri = uri;
            backgroundImageUri = null;
        }
        updateOutputs();
    }

    @Override
    protected void onDestroy() {
        disconnectPresentation();
        super.onDestroy();
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextAllCaps(false);
        b.setMinHeight(dp(48));
        return b;
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        return lp;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        return lp;
    }

    private FrameLayout.LayoutParams frameMatch() {
        return new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
