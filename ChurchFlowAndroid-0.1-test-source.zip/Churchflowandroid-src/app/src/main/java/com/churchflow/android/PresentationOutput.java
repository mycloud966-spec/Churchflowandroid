package com.churchflow.android;

import android.app.Presentation;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import java.io.InputStream;

public class PresentationOutput extends Presentation {
    private FrameLayout root;
    private ImageView imageView;
    private VideoView videoView;
    private TextView textView;
    private View blackoutView;
    private Uri currentImage;
    private Uri currentVideo;

    public PresentationOutput(Context outerContext, Display display) {
        super(outerContext, display);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(getContext());
        root.setBackgroundColor(Color.BLACK);

        imageView = new ImageView(getContext());
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(imageView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        videoView = new VideoView(getContext());
        videoView.setVisibility(View.GONE);
        root.addView(videoView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        View shade = new View(getContext());
        shade.setBackgroundColor(0x55000000);
        root.addView(shade, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        textView = new TextView(getContext());
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(44f);
        textView.setGravity(Gravity.CENTER);
        textView.setShadowLayer(10f, 0f, 3f, Color.BLACK);
        textView.setPadding(64, 48, 64, 48);
        root.addView(textView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        blackoutView = new View(getContext());
        blackoutView.setBackgroundColor(Color.BLACK);
        blackoutView.setVisibility(View.GONE);
        root.addView(blackoutView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);
    }

    public void update(String slideText, boolean blackout, Uri imageUri, Uri videoUri) {
        if (textView == null) return;
        textView.setText(slideText == null ? "" : slideText);
        blackoutView.setVisibility(blackout ? View.VISIBLE : View.GONE);

        if (videoUri != null) {
            if (!videoUri.equals(currentVideo)) {
                currentVideo = videoUri;
                currentImage = null;
                imageView.setImageDrawable(null);
                videoView.setVideoURI(videoUri);
                videoView.setOnPreparedListener(mp -> {
                    mp.setLooping(true);
                    videoView.start();
                });
            }
            videoView.setVisibility(View.VISIBLE);
        } else {
            if (videoView.isPlaying()) videoView.stopPlayback();
            videoView.setVisibility(View.GONE);
            currentVideo = null;
        }

        if (imageUri != null && videoUri == null) {
            if (!imageUri.equals(currentImage)) {
                currentImage = imageUri;
                try (InputStream in = getContext().getContentResolver().openInputStream(imageUri)) {
                    Drawable drawable = Drawable.createFromStream(in, imageUri.toString());
                    imageView.setImageDrawable(drawable);
                } catch (Exception ignored) {
                    imageView.setImageDrawable(null);
                }
            }
        } else if (imageUri == null) {
            currentImage = null;
            imageView.setImageDrawable(null);
        }
    }
}
