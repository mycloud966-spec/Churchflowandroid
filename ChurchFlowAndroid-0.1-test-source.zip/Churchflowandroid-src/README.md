# ChurchFlow Android — 0.1 test build

This repository contains the Android-first ChurchFlow test app.

## Current test features

- Phone-side ChurchFlow control UI
- Telugu/English lyrics entry
- 2-lines-per-slide split
- Previous / Next controls
- Blackout toggle
- Local background image picker
- Local background video picker
- `TV Cast` action for Android secondary/presentation displays
- Separate clean full-screen TV output using Android `Presentation` (not phone UI mirroring)
- Disconnect TV action
- Standalone browser prototype retained under `preview/`
- GitHub Actions workflow that builds a debug APK artifact

## APK build

Open the repository **Actions** tab and run **Build Android APK**, or push to `main`.
After a successful run, download the artifact named:

`ChurchFlow-Android-debug-apk`

Inside the artifact ZIP is `app-debug.apk`.

## Important test limitation

The current `TV Cast` button uses Android's secondary-display / presentation-display API. A compatible secondary display must already be exposed to Android. Direct Google Cast / Chromecast session control is intentionally reserved for a later build.
